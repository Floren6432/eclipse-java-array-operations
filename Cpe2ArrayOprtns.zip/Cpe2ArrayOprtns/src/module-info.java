/**
 * 
 */
/**
 * @author Floren Go
 *
 */
module Cpe2ArrayOprtns {
}